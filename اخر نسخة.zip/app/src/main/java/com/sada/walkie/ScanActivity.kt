package com.sada.walkie

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.Size
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.min

/**
 * ماسح QR مدمج: كاميرا CameraX + نموذج ML Kit مرفق داخل التطبيق.
 * لا يحتاج إنترنت ولا خدمات Google Play، ويمسح الإطار كاملاً (لا حاجة لتوجيه دقيق).
 * يعيد النص فور قراءة رمز من التطبيق (يبدأ بـ SADA|) ثم يُغلق نفسه.
 */
class ScanActivity : ComponentActivity() {
    companion object {
        const val EXTRA_TEXT = "text"
        const val EXTRA_ERR = "err"
        const val MARK = "SADA|"
    }

    private lateinit var preview: PreviewView
    private lateinit var hint: TextView
    private lateinit var torchBtn: TextView
    private var camera: Camera? = null
    private var provider: ProcessCameraProvider? = null
    private val exec = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    @Volatile private var done = false
    private var torchOn = false
    private var lastWarn = 0L

    private val scanner by lazy {
        BarcodeScanning.getClient(
            BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
        )
    }

    private val permReq = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startCamera() else finishWith(null, "camera")
    }

    /** إطار التوجيه: تعتيم حول مربع شفاف مع زوايا واضحة. */
    private class Frame(c: android.content.Context) : View(c) {
        private val dim = Paint().apply { color = Color.parseColor("#99000000") }
        private val corner = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 6f * resources.displayMetrics.density
            strokeCap = Paint.Cap.ROUND
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val s = min(w, h) * 0.72f
            val l = (w - s) / 2f; val t = (h - s) / 2f - h * 0.04f
            val r = RectF(l, t, l + s, t + s)
            val rad = 22f * resources.displayMetrics.density
            val p = Path()
            p.fillType = Path.FillType.EVEN_ODD
            p.addRect(0f, 0f, w, h, Path.Direction.CW)
            p.addRoundRect(r, rad, rad, Path.Direction.CW)
            c.drawPath(p, dim)
            val k = s * 0.14f
            val x1 = r.left; val x2 = r.right; val y1 = r.top; val y2 = r.bottom
            c.drawLine(x1, y1 + k, x1, y1, corner); c.drawLine(x1, y1, x1 + k, y1, corner)
            c.drawLine(x2 - k, y1, x2, y1, corner); c.drawLine(x2, y1, x2, y1 + k, corner)
            c.drawLine(x1, y2 - k, x1, y2, corner); c.drawLine(x1, y2, x1 + k, y2, corner)
            c.drawLine(x2 - k, y2, x2, y2, corner); c.drawLine(x2, y2, x2, y2 - k, corner)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun pill(text: String, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        setTextColor(Color.WHITE)
        textSize = 16f
        gravity = Gravity.CENTER
        setPadding(dp(22), dp(12), dp(22), dp(12))
        background = GradientDrawable().apply { setColor(Color.parseColor("#CC1A1A1A")); cornerRadius = dp(26).toFloat() }
        setOnClickListener { onClick() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)
        preview = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        root.addView(preview, FrameLayout.LayoutParams(-1, -1))
        root.addView(Frame(this), FrameLayout.LayoutParams(-1, -1))

        hint = TextView(this).apply {
            text = "وجّه الكاميرا نحو رمز QR على شاشة المضيف\nسيتصل تلقائياً فور القراءة"
            setTextColor(Color.WHITE)
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = GradientDrawable().apply { setColor(Color.parseColor("#B3000000")); cornerRadius = dp(18).toFloat() }
        }
        root.addView(hint, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(48) })

        val bar = FrameLayout(this)
        torchBtn = pill("💡 إضاءة") { toggleTorch() }
        val cancel = pill("إلغاء") { finishWith(null, null) }
        bar.addView(torchBtn, FrameLayout.LayoutParams(-2, -2, Gravity.START or Gravity.CENTER_VERTICAL))
        bar.addView(cancel, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL))
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
            setMargins(dp(24), 0, dp(24), dp(40))
        })

        // اضغط على الشاشة للتركيز اليدوي
        preview.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_UP) {
                try {
                    val pt = preview.meteringPointFactory.createPoint(e.x, e.y)
                    camera?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                } catch (_: Exception) {}
                v.performClick()
            }
            true
        }
        setContentView(root)

        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else permReq.launch(Manifest.permission.CAMERA)
    }

    private fun toggleTorch() {
        val c = camera ?: return
        if (!c.cameraInfo.hasFlashUnit()) return
        torchOn = !torchOn
        c.cameraControl.enableTorch(torchOn)
        torchBtn.text = if (torchOn) "💡 إطفاء الإضاءة" else "💡 إضاءة"
    }

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            try {
                val p = f.get()
                provider = p
                val pv = Preview.Builder().build()
                pv.setSurfaceProvider(preview.surfaceProvider)
                val an = ImageAnalysis.Builder()
                    .setTargetResolution(Size(720, 1280))
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                an.setAnalyzer(exec) { img -> analyze(img) }
                p.unbindAll()
                camera = p.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, pv, an)
            } catch (_: Exception) {
                finishWith(null, "camera")
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(img: ImageProxy) {
        if (done || !busy.compareAndSet(false, true)) { img.close(); return }
        try {
            val bmp = img.toBitmap()
            val rot = img.imageInfo.rotationDegrees
            img.close()
            scanner.process(InputImage.fromBitmap(bmp, rot))
                .addOnSuccessListener { list -> onCodes(list.mapNotNull { it.rawValue }) }
                .addOnCompleteListener { busy.set(false) }
        } catch (_: Exception) {
            try { img.close() } catch (_: Exception) {}
            busy.set(false)
        }
    }

    private fun onCodes(texts: List<String>) {
        if (done || texts.isEmpty()) return
        val ours = texts.firstOrNull { it.startsWith(MARK) }
        if (ours != null) { finishWith(ours, null); return }
        val now = System.currentTimeMillis()
        if (now - lastWarn > 2500) {
            lastWarn = now
            hint.text = "هذا الرمز ليس من التطبيق — امسح رمز المضيف"
        }
    }

    private fun finishWith(text: String?, err: String?) {
        if (done) return
        done = true
        if (text != null) {
            try { window.decorView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS) } catch (_: Exception) {}
            setResult(RESULT_OK, Intent().putExtra(EXTRA_TEXT, text))
        } else {
            setResult(RESULT_CANCELED, Intent().putExtra(EXTRA_ERR, err ?: ""))
        }
        finish()
    }

    override fun onDestroy() {
        done = true
        try { provider?.unbindAll() } catch (_: Exception) {}
        try { scanner.close() } catch (_: Exception) {}
        exec.shutdown()
        super.onDestroy()
    }
}
